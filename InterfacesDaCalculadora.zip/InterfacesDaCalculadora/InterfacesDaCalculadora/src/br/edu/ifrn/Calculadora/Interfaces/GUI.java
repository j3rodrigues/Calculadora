package br.edu.ifrn.Calculadora.Interfaces;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JFormattedTextField;
import javax.swing.JSpinner;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Window.Type;
import javax.swing.border.TitledBorder;

import br.edu.ifrn.Calculadora.Codigos.*;

import javax.swing.JToggleButton;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI extends JFrame {
	
	Calculadora calc = new Calculadora(0, 0, 0, 0, null);
	
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	
	private String op1;
	private String op2;
	private double d1;
	private double d2;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GUI() {
		setBackground(new Color(128, 128, 128));
		setForeground(new Color(128, 128, 128));
		setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 20));
		setTitle("CALCULADORA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230, 115, 126));
		contentPane.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(321, 18, -82, 22);
		contentPane.add(textArea);
		
		JLabel lblNewLabel = new JLabel("Insira primeiro numero");
		lblNewLabel.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel.setForeground(new Color(180, 37, 58));
		lblNewLabel.setBounds(24, 56, 184, 29);
		contentPane.add(lblNewLabel);
		

		textField = new JTextField();
		textField.setBackground(new Color(219, 219, 219));
		textField.setBounds(47, 82, 121, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblInsiraSegundoNumero = new JLabel("Insira segundo numero");
		lblInsiraSegundoNumero.setForeground(new Color(180, 37, 58));
		lblInsiraSegundoNumero.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 15));
		lblInsiraSegundoNumero.setBounds(24, 117, 180, 29);
		contentPane.add(lblInsiraSegundoNumero);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(219, 219, 219));
		textField_3.setBounds(47, 143, 121, 22);
		contentPane.add(textField_3);
		
		JLabel lblNewLabel_1 = new JLabel("Opera\u00E7\u00E3o");
		lblNewLabel_1.setForeground(new Color(180, 37, 58));
		lblNewLabel_1.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(247, 57, 113, 22);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Resultado:");
		lblNewLabel_2.setFont(new Font("Bell MT", Font.BOLD, 20));
		lblNewLabel_2.setForeground(new Color(180, 37, 58));
		lblNewLabel_2.setBackground(new Color(192, 192, 192));
		lblNewLabel_2.setBounds(229, 138, 121, 22);
		contentPane.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Bell MT", Font.PLAIN, 13));
		textField_1.setBackground(new Color(219, 219, 219));
		textField_1.setBounds(338, 141, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setFont(new Font("Bell MT", Font.ITALIC, 15));
		comboBox.setForeground(new Color(233, 75, 87));
		comboBox.setBackground(new Color(219, 219, 219));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Escolha", "Soma       ", "Subtracao     ", "Multiplicacao", "Divisao     "}));
		comboBox.setBounds(247, 82, 101, 22);
		contentPane.add(comboBox);
		
		JButton btnNewButton_1 = new JButton("Calcular");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				op1 = textField.getText();
				d1 = Double.parseDouble(op1);
				calc.setNum1(d1);
				op2 = textField_3.getText();
				d2 = Double.parseDouble(op2);
				calc.setNum2(d2);
				
				switch (comboBox.getSelectedIndex()) {
				case 1:
					calc.setOperador(2);
					break;
				case 2:
					calc.setOperador(3);
					break;
				case 3:
					calc.setOperador(4);
				break;
				case 4:
					calc.setOperador(5);
				break;
				}
				calc.realizarOperacao();
				textField_1.setText(Double.toString(calc.getResultado()));
			}
		});
		btnNewButton_1.setForeground(new Color(0, 0, 0));
		btnNewButton_1.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 15));
		btnNewButton_1.setBackground(new Color(219, 219, 219));
		btnNewButton_1.setBounds(35, 190, 133, 23);
		contentPane.add(btnNewButton_1);
		
//		textField_2 = new JTextField();
//		textField_2.setBackground(new Color(219, 219, 219));
//		textField_2.setBounds(274, 212, 123, 20);
//		contentPane.add(textField_2);
//		textField_2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("CALCULADORA");
		lblNewLabel_4.setFont(new Font("Bell MT", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_4.setForeground(new Color(180, 37, 58));
		lblNewLabel_4.setBounds(120, 18, 166, 22);
		contentPane.add(lblNewLabel_4);
		
		
		
		
	}
}
