package br.edu.ifrn.Calculadora.Codigos;

import br.edu.ifrn.Calculadora.Interfaces.*;

public class Funcionando {

	public static void main(String[] args) {
		TUI tui = new TUI ();
	
		tui.rodando();
	}

}
