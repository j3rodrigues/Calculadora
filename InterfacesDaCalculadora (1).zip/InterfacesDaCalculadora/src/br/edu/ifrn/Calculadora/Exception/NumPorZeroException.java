package br.edu.ifrn.Calculadora.Exception;

public class NumPorZeroException extends Exception{
	public NumPorZeroException(String nz) {
		super(nz);
	}

}
