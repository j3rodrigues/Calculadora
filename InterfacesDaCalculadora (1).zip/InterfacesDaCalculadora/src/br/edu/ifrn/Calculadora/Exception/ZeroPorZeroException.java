package br.edu.ifrn.Calculadora.Exception;

public class ZeroPorZeroException extends Exception{
	public ZeroPorZeroException(String zz) {
		super(zz);
	}
}
